package ticTacToe.model.score;

public class ScoreView {

}
