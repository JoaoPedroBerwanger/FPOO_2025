package ticTacToe.model.score;

public interface ReadOnlyScoreModel {

	int scoreX();
	int scoreO();
}
