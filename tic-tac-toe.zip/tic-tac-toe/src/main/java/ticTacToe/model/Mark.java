package ticTacToe.model;

public enum Mark { X, O, BLANK;

}
