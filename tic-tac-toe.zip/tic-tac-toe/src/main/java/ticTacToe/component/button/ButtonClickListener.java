package ticTacToe.component.button;

public interface ButtonClickListener {

}
