package ticTacToe.component.button;

public class ButtonClickEvent {

}
