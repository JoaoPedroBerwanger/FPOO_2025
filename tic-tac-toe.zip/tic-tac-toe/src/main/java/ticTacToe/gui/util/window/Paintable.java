package ticTacToe.gui.util.window;

import java.awt.*;

public interface Paintable {
	
   void paint(Graphics g);
}
