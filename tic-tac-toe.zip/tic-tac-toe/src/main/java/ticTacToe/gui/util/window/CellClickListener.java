package ticTacToe.gui.util.window;

public interface CellClickListener {
	void onClick(CellClickEvent event);
}
